<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-03-20 18:13:01 --> Error - date_default_timezone_get(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'America/New_York' for 'EDT/-4.0/DST' instead in /Users/russellbenton/Desktop/ASL/lab/lab6/twittera/fuel/core/classes/fuel.php on line 161
