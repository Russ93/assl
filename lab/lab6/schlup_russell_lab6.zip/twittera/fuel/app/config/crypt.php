<?php
return array(
	'crypto_key' => 'ImIClYJ-ovi0q0chnQxlw8qc',
	'crypto_iv' => 'GDMCQggg8LwouEMkBAlUA068',
	'crypto_hmac' => 'FqUNncYXcrHYUxoaOQDjUnCs',
);
