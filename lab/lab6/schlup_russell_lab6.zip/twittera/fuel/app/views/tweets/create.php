<h2>New <span class='muted'>Tweet</span></h2>
<br>

<?php echo render('tweets/_form'); ?>


<p><?php echo Html::anchor('tweets', 'Back'); ?></p>
