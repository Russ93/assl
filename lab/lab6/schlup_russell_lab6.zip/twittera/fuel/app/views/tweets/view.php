<h2>Viewing <span class='muted'>#<?php echo $tweet->id; ?></span></h2>

<p>
	<strong>Name:</strong>
	<?php echo $tweet->name; ?></p>
<p>
	<strong>Header:</strong>
	<?php echo $tweet->header; ?></p>
<p>
	<strong>Message:</strong>
	<?php echo $tweet->message; ?></p>

<?php echo Html::anchor('tweets/edit/'.$tweet->id, 'Edit'); ?> |
<?php echo Html::anchor('tweets', 'Back'); ?>