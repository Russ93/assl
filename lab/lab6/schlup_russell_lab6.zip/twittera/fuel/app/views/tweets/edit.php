<h2>Editing <span class='muted'>Tweet</span></h2>
<br>

<?php echo render('tweets/_form'); ?>
<p>
	<?php echo Html::anchor('tweets/view/'.$tweet->id, 'View'); ?> |
	<?php echo Html::anchor('tweets', 'Back'); ?></p>
