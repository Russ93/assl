<h2>Listing <span class='muted'>Tweets</span></h2>
<br>
<?php if ($tweets): ?>
<table class="table table-striped">
	<thead>
		<tr>
			<th>Name</th>
			<th>Header</th>
			<th>Message</th>
			<th>&nbsp;</th>
		</tr>
	</thead>
	<tbody>
<?php foreach ($tweets as $item): ?>		<tr>

			<td><?php echo $item->name; ?></td>
			<td><?php echo $item->header; ?></td>
			<td><?php echo $item->message; ?></td>
			<td>
				<div class="btn-toolbar">
					<div class="btn-group">
						<?php echo Html::anchor('tweets/view/'.$item->id, '<i class="icon-eye-open"></i> View', array('class' => 'btn btn-small')); ?>						<?php echo Html::anchor('tweets/edit/'.$item->id, '<i class="icon-wrench"></i> Edit', array('class' => 'btn btn-small')); ?>						<?php echo Html::anchor('tweets/delete/'.$item->id, '<i class="icon-trash icon-white"></i> Delete', array('class' => 'btn btn-small btn-danger', 'onclick' => "return confirm('Are you sure?')")); ?>					</div>
				</div>

			</td>
		</tr>
<?php endforeach; ?>	</tbody>
</table>

<?php else: ?>
<p>No Tweets.</p>

<?php endif; ?><p>
	<?php echo Html::anchor('tweets/create', 'Add new Tweet', array('class' => 'btn btn-success')); ?>

</p>
